# Bộ trang web ExamMark (tĩnh) — hướng dẫn triển khai

Gồm 4 trang HTML tĩnh (không cần máy chủ, không cần JavaScript):

| Tệp | Nội dung |
|---|---|
| `index.html` | Trang chủ + nút tải APK + hướng dẫn cài nhanh |
| `gioi-thieu.html` | Vai trò, chức năng, cấu trúc phiếu, cách chấm điểm |
| `huong-dan.html` | Hướng dẫn sử dụng từng chức năng (23 mục, gồm Ngân hàng câu hỏi, Trộn đề, Kỳ thi nhóm, Chấm tự luận, Giao bài & chấm thi online), xử lý sự cố, FAQ |
| `privacy.html` | **Chính sách quyền riêng tư** (dùng làm URL chính sách) |
| `assets/` | CSS, logo, hình minh hoạ (phiếu A4/A5 do chính app sinh, 12 sơ đồ SVG) |

## 1. Đưa lên GitHub Pages (miễn phí, không cần tên miền)
1. Tạo tài khoản GitHub, tạo repo **public**, ví dụ `exammark`.
2. Tải toàn bộ nội dung thư mục này lên **gốc** repo (`index.html` nằm ngay ở gốc).
3. Repo → *Settings → Pages* → *Build and deployment*: Source = **Deploy from a branch**, Branch = `main`, thư mục `/ (root)` → Save.
4. Sau 1–2 phút, trang chạy tại `https://<tên-tài-khoản>.github.io/exammark/`.
   Chính sách riêng tư: `https://<tên-tài-khoản>.github.io/exammark/privacy.html`.

## 2. Phát hành APK bằng GitHub Releases
1. Repo → *Releases → Draft a new release* → đặt tag `v1.0.0`.
2. Kéo thả tệp **APK đã ký bản release** (không dùng APK debug) vào mục *Attach binaries*.
3. Trong phần mô tả, ghi **mã SHA-256** của tệp. Tính trên Windows:
   `certutil -hashfile ExamMark.apk SHA256`
4. Publish. Link tải mới nhất luôn là `https://github.com/<tên-tài-khoản>/<repo>/releases/latest`.

## 3. Việc BẮT BUỘC phải sửa trước khi công khai
- [ ] **`index.html`**: thay `TEN-TAI-KHOAN/ten-repo` trong nút “Tải ExamMark cho Android (APK)” bằng địa chỉ GitHub thật (tìm dòng có chú thích `TODO`).
- [ ] **`index.html`** — “Android 8.0 trở lên (khuyến nghị)”: đối chiếu với `minSdkVersion` thật trong `mobile/android/variables.gradle` và sửa cho đúng.
- [ ] **`huong-dan.html` mục 17 (Tab Đồng bộ, trước đây là mục 16)**: đối chiếu mô tả với bản APK hiện hành (có chú thích `TODO` trong mã).
- [ ] **Xác nhận các thông tin mặc định** nêu trong trang: dùng thử 14 ngày; license cần làm mới sau khoảng 7 ngày (+ ân hạn); tệp xuất nằm ở *Tài liệu/ExamMark*. Nếu bạn đã đổi cấu hình gói trong Google Sheet bản quyền, sửa lại cho khớp.
- [ ] **`privacy.html`**: đọc kỹ từng mục, bảo đảm khớp thực tế (đặc biệt bảng ở mục 2). Nếu sau này thêm quảng cáo, công cụ thống kê, hay máy chủ lưu dữ liệu, **phải cập nhật** chính sách và ngày hiệu lực. Nên nhờ người am hiểu pháp lý rà soát.
- [ ] **`privacy.html` — phần MỚI cần bạn xác nhận** (bản cập nhật 10/10/2026): mục 5 (Group Hub), mục 6 (chấm tự luận bằng AI), các hàng mới ở bảng mục 2, ngày hiệu lực, và đoạn English summary. Đặc biệt kiểm tra: (a) đề đẩy lên Hub có kèm *danh sách thí sinh* không; (b) các nhà cung cấp AI đang hỗ trợ (Gemini, OpenAI, Claude); (c) có ghi nhận “Nghị định 13/2023” khi dữ liệu học sinh tới bên thứ ba/nước ngoài không.
- [ ] **Nhãn “Bản thử nghiệm” của Chấm tự luận** (mục 15 + trang Giới thiệu/Trang chủ): theo tài liệu bàn giao, tính năng chưa được kiểm chứng với AI thật và điện thoại thật. Bỏ nhãn khi bạn thấy đã đủ ổn định.
- [ ] **Quyền tự luận theo gói** (mục 15.1): trang chỉ nói chung “tuỳ gói license”. Nếu đã chốt gói nào có quyền tự luận/rà soát, ghi cụ thể.
- [ ] **Giao bài & chấm thi online (mục 16, thêm ở bản cập nhật theo ExamMark v38)** — cần bạn xác nhận trước khi đăng:
  - Nội dung viết theo `docs/25`–`28` và mã nguồn v38; theo chính các tài liệu đó, Phòng thi **mới kiểm trên mô phỏng Apps Script, chưa chạy trên Google/điện thoại thật** (thí sinh ẩn danh, toàn màn hình trong iframe, đồng thời 30 lượt, gửi email, Safari/iOS). Mục 16 đã nói rõ “chức năng mới, hãy thử trước”; sau khi bạn thử thật, cập nhật hoặc bỏ nhãn **Mới** và các lưu ý đó.
  - Mục 16.2 nói giáo viên “nhận liên kết Tạo bản sao từ nhà phát triển”: hãy chắc bạn thực sự phát liên kết bản mẫu *ExamRoom (bản mẫu)*; nếu cách phân phối khác (ví dụ trang tải về), sửa câu này. Chưa kiểm chứng việc “Tạo bản sao” mang theo mã Apps Script (`docs/27` §8).
  - Số liệu giới hạn (≈150 em vào thi cùng lúc, 100/1 500 email mỗi ngày, ≈1 500 bài/bài thi, hình ≈1,5 MB) lấy từ `docs/25` §7; số của Google có thể đổi.
  - `privacy.html` đã thêm **mục 7 (Phòng thi)**, hàng mới ở bảng mục 2, thay đổi mục 9–13, đoạn English summary, sơ đồ `dataflow.svg`, và **đổi ngày hiệu lực thành 11/10/2026**. Cần bạn (hoặc người am hiểu pháp lý) rà soát, đặc biệt: (a) việc ghi “số lần và thời điểm rời màn hình” của học sinh; (b) mục 12 — trang làm bài của học sinh (có thể là trẻ em) không còn khớp với câu cũ “không dành cho học sinh tự sử dụng”, nay đã viết lại thành trách nhiệm của giáo viên/nhà trường; (c) trang học sinh tải KaTeX từ **jsDelivr** (bên thứ ba); (d) việc Phòng thi **không** nằm trong sao lưu/license của app.
  - Mục 2 và 15.2 đã đổi “ô chọn chế độ” thành 3 lựa chọn. Các ảnh `02-man-hinh-chinh.png` và `28-tu-luan-chon-che-do.png` cần chụp lại khi có ảnh mới.
  - Phần Ngân hàng/Soạn đề của v38 (“giao diện gọn”) **chưa được rà soát lại** trong lần cập nhật này, vì yêu cầu chỉ gồm chức năng giao bài online.
- [ ] **Danh mục mặc định chỉ có Toán 10–12** (mục 6.3): nếu bổ sung môn khác trong app, cập nhật câu này.

## 4. Điền thông tin lên Google Auth platform (OAuth)
Trong *Google Cloud Console → Google Auth platform → Branding*:
- Tên ứng dụng: `ExamMark`; Email hỗ trợ và email liên hệ nhà phát triển: `phanchienmdc@gmail.com`.
- Liên kết chính sách quyền riêng tư: URL `privacy.html` ở trên; Trang chủ: URL `index.html`.
- Logo: `assets/img/logo-192.png` (hoặc `mobile/assets/icon-store-512.png`).
- Lưu ý: xác minh thương hiệu (hiện tên/logo trên màn hình đồng ý) đòi hỏi tên miền do bạn sở hữu; tên miền `github.io` thường **không** đạt. Không bắt buộc với scope không nhạy cảm — bỏ qua cũng không chặn việc publish.

## 5. Chèn ảnh chụp màn hình (làm sau cũng được)
Trong `huong-dan.html` có các **khung trống nét đứt**. Chỉ cần chụp màn hình app, đặt tên **đúng như bảng dưới**, thả vào thư mục `assets/img/shots/` — ảnh tự hiện, **không cần sửa mã HTML**. Khung trống sẽ tự biến mất khi có ảnh đúng tên. Nên dùng PNG/JPG, rộng khoảng 600–800 px.

| Tên tệp | Nên chụp gì |
|---|---|
| `01-kich-hoat.png` | Màn hình “Kích hoạt ExamMark” (ô nhập mã, nút dùng thử) |
| `02-man-hinh-chinh.png` | ⚠️ **Nên chụp lại:** màn hình chính nay có **6 tab** (Kỳ thi · Soạn đề · Chấm bài · Kết quả · Nhóm · Đồng bộ), nút ⚙️ và ô chọn chế độ ở thanh tiêu đề |
| `03-tao-mau-phieu.png` | Form “Tạo mẫu phiếu mới” (khổ giấy, số câu, số chữ số SBD/mã đề) |
| `04-xem-truoc-mau-phieu.png` | Ảnh xem trước phiếu sau “Sinh & xem trước mẫu phiếu” |
| `05-tao-ky-thi.png` | Danh sách “Kỳ thi của tôi” với nút “Dùng kỳ thi này” |
| `06-soan-de-dap-an.png` | Khối “Xem & sửa đề hiện tại” (mã đề + đáp án) |
| `07-nhap-dap-an-excel.png` | Khối “Nhập đáp án hàng loạt từ Excel/CSV” |
| `08-danh-sach-thi-sinh.png` | Mục “Danh sách thí sinh” (Thêm thí sinh / Tải file mẫu / Import) |
| `09-tai-phieu-pdf.png` | Mục “Phiếu trống để in…” với nút “Tải phiếu trống (PDF)” |
| `10-cham-bai-chup.png` | Camera trong tab Chấm bài khi canh 4 góc phiếu |
| `11-ket-qua-nhan-dang.png` | Khối “Kết quả nhận dạng” (SBD, mã đề, điểm, câu cần xem lại) |
| `12-cau-can-xem-lai.png` | Danh sách “Các câu cần xem lại” + bảng chi tiết bài chấm (⚠️ hiện **trùng hệt** `11-…png` — nên thay bằng ảnh khác) |
| `13-xuat-ket-qua.png` | Tab Kết quả: nút Xuất Excel / Xuất CSV |
| `14-sao-luu-drive.png` | Mục “Sao lưu Google Drive cá nhân” trong ⚙️ |
| `15-quan-ly-to-chuc.png` | ⚠️ **Nên chụp lại:** quản lý tổ chức — bảng thành viên (cột “Máy / tối đa”), dòng “đã dùng … chỗ thiết bị … đang giữ chỗ”, ô hạn mức thiết bị |
| **— Mới: Ngân hàng câu hỏi (mục 6) —** | |
| `16-ngan-hang-nap-excel.png` | Tab Soạn đề → “📖 Ngân hàng câu hỏi” → mục ① nạp Excel/CSV, sau khi bấm “🔍 Đọc & kiểm tra” (bảng xem trước có câu hợp lệ và câu lỗi) |
| `17-ngan-hang-danh-sach-loc.png` | Mục ② “Danh sách câu đã lưu”: các ô lọc, vài câu được tick, hàng nút thao tác hàng loạt |
| `18-ngan-hang-danh-muc-ma-cau.png` | “👁️ Xem danh mục & quy tắc mã”: khung quy tắc mã và bảng chủ đề Toán 12 |
| `19-ngan-hang-nhat-ma-tran.png` | Mục ③ “Nhặt câu để tạo đề” với 2–3 dòng ma trận và kết quả nhặt |
| `20-ngan-hang-trinh-sua-cau.png` | Mục ④ “Thêm / sửa một câu” đang mở (một câu Phần I có công thức LaTeX) |
| **— Mới: Trộn đề (mục 7) —** | |
| `21-tron-de-xem-thu.png` | Khung “🔀 Trộn đề & xuất đề” sau “🔀 Xem thử” (số mã đề, mã đề đầu, tuỳ chọn đảo, bảng đáp án gộp) |
| `22-tron-de-xuat-de.png` | Mục “Các mã đề của kỳ thi & xuất…” với nút Excel / Gói LaTeX |
| **— Mới: Kỳ thi nhóm (mục 14) —** | |
| `23-nhom-quan-tri.png` | Tab 👥 Nhóm (tài khoản quản trị): “📥 Cần xử lý”, danh sách nhóm con (che email thật) |
| `24-nhom-day-ky-thi.png` | Khung “⬆️ Đẩy kỳ thi lên Hub”, chọn “Phân công theo lớp/phòng thi” với dòng mẫu (email giả) |
| `25-nhom-giao-vien.png` | Tab 👥 Nhóm (tài khoản giáo viên): thẻ kỳ thi chung có nhãn trạng thái và nút “⬇️ Tải về để chấm” / “✅ Hoàn thiện & gửi kết quả” |
| `26-nhom-ket-qua-duyet.png` | “📋 Kết quả” của một kỳ thi: tiến độ, danh sách giáo viên, nút Chi tiết/Duyệt/Yêu cầu chấm lại (nên thêm ảnh bảng “🔍 Chi tiết”) |
| `27-nhom-bien-ban.png` | Mục “🗂 Kỳ thi đã kết thúc” + nội dung một biên bản |
| **— Mới: Thống kê (mục 13) —** | |
| `35-thong-ke-ky-thi.png` | Tab Kết quả → “📈 Thống kê kỳ thi” sau “📈 Xem thống kê” (phạm vi “Chỉ mã đề đang chọn” để thấy bảng từng câu tô đỏ) |
| **— Mới: Chấm tự luận (mục 15) —** | |
| `28-tu-luan-chon-che-do.png` | Ô chọn “📱 Chấm trắc nghiệm / 🤖 Chấm tự luận” ở thanh tiêu đề; thêm ảnh giao diện tự luận với 4 mục 📚 📝 📊 ⚙️ |
| `29-tu-luan-cai-dat-ai.png` | ⚙️ Cài đặt tự luận: nhà cung cấp, ô khoá API (**phải che khoá thật**), nút “Lấy danh sách mô hình”, “Kiểm tra kết nối” |
| `30-tu-luan-ky-thi.png` | Form kỳ thi tự luận: ba ô Đề/Đáp án/Barem, nút “📷 Từ ảnh”, “📄 Từ tệp”, “🪄 Tách tự động từ 1 tệp/ảnh” |
| `31-tu-luan-bai-lam.png` | Mục “📝 Bài làm”: thanh tiến độ, nút “⚡ Chấm tất cả chưa chấm”, danh sách thí sinh (che họ tên thật) |
| `32-tu-luan-chi-tiet-cham.png` | Chi tiết một bài đã chấm: ảnh bài làm, bản chép, điểm từng ý, cờ “⚠️ Cần xem lại” |
| `33-tu-luan-ket-qua-xuat.png` | Mục “📊 Kết quả” tự luận với nút ⬇ CSV / ⬇ Excel / ⬇ JSON |
| `34-tu-luan-chia-se-ra-soat.png` | Màn “📤 Chia sẻ để rà soát”: chọn bài, ô “Kèm ảnh bài làm” (mặc định tắt), nút “📦 Tạo & tải gói” |
| **— Mới: Giao bài & chấm thi online (mục 16) —** | |
| `36-phong-thi-chon-che-do.png` | Ô chọn chế độ ở thanh tiêu đề mở ra 3 lựa chọn (Trắc nghiệm / Tự luận / 🌐 Phòng thi online); thêm ảnh trang Phòng thi đã kết nối với 3 nhóm 🔌 📤 📋 (**che địa chỉ thật**) |
| `37-phong-thi-menu-examroom.png` | Menu “🌐 ExamRoom” trong Google Sheet (⓪ … ⑤, ④b, Kiểm tra tình trạng); thêm ảnh hộp thoại cuối có địa chỉ …/exec và khoá (**che khoá thật**) |
| `38-phong-thi-giao-bai.png` | Nhóm “📤 Giao bài mới”: danh sách câu đã tick, Tên/Thời gian/Thang điểm, các ô cài đặt, nút “🚀 Giao bài & mở” |
| `39-phong-thi-ma-qr.png` | Khung “Đã giao bài”: mã vào thi, đường dẫn, nút Sao chép, mã QR (dùng bài thử) |
| `40-phong-thi-hoc-sinh.png` | Màn hình làm bài của học sinh trên điện thoại (đồng hồ, công thức, lưới câu) + “📋 Tổng quan đề” (họ tên giả) |
| `41-phong-thi-theo-doi.png` | “📋 Bài đã giao” + “📡 Theo dõi”: đang làm/đã nộp, cột Rời MH, nút +10′ / Làm lại (họ tên giả) |
| `42-phong-thi-ket-qua.png` | “📊 Kết quả”: thống kê, nhận xét, hàng ô tick “Gửi email”, bảng điểm (họ tên và email giả) |
| `43-phong-thi-nhap-ky-thi.png` | “📥 Nhập kết quả online vào kỳ thi trong App” sau khi bấm Xem trước |

(Tổng cộng 43 vị trí ảnh; 28 vị trí mới đang để khung chờ. Số 35 được dùng cho thống kê vì thêm sau nên không nằm liền mạch; các ảnh Phòng thi dùng số 36–43.)

**Lưu ý riêng tư khi chụp:** che hoặc dùng dữ liệu giả cho tên học sinh, email, mã license trong ảnh.

## 5b. Sơ đồ SVG mới (đã dựng sẵn, không cần làm gì)
`flow-soan-de.svg`, `ma-cau.svg`, `tron-de.svg`, `ky-thi-nhom.svg`, `vong-doi-nhom.svg`, `tu-luan-flow.svg`, `tu-luan-chia-se.svg`, `giao-bai-online-flow.svg` (mới, quy trình giao bài online); và `dataflow.svg` đã được **vẽ lại** (thêm Group Hub, nhà cung cấp AI và — ở bản này — Phòng thi online) cho trang Quyền riêng tư.

## 6. Cập nhật sau này
- Ra phiên bản mới: tạo Release mới, cập nhật mã SHA-256, và sửa số phiên bản nếu bạn có ghi trên trang.
- Đổi nội dung: sửa trực tiếp các tệp `.html` (văn bản thuần, dễ sửa); màu và kiểu chữ nằm trong `assets/style.css`.
- Hình phiếu minh hoạ trong `assets/img/` do chính app sinh (mẫu 40/8/6 câu cho A4, 12/4/6 cho A5, kèm đáp án tô thử); có thể dựng lại khi giao diện phiếu thay đổi.
